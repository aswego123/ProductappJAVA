package com.training.spring.pms.model;

public class Message {
	public Message() {
		System.out.println("Message caller");
	}
	public String sayHello() {
		return "Hello bangalore from message.java";
	}
}
