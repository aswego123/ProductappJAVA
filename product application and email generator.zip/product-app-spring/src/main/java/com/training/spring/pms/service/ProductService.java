package com.training.spring.pms.service;

import com.training.spring.pms.model.Product;

public interface ProductService {

	void updateProduct(Product product);
	void saveProduct(Product product);

}
