package com.resttraining;

import java.time.LocalDateTime;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.PathParam;

@Path("hello")
public class Hi {

	@Path(value = "msg/{name}")			//http://localhost:8080/RESTfulExample/rest/hello/msg
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String  hello(@PathParam("name")String n) {
			return "Hi "+n;
	}
	
	@Path(value = "product")			//http://localhost:8080/RESTfulExample/rest/hello/msg
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String  hi() {
			return "Hi Product App";
	}
	
	LocalDateTime time=LocalDateTime.now();
	@Path(value="hour")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String wish() {
		if(time.getHour()<12)
			return "Good Morning!";
		else if(time.getHour()>12 && time.getHour()<16)
				return "Good Afternoon!";
		else 
			return "Good Night!";
		
	}
}
