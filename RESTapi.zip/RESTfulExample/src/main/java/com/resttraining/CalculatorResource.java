package com.resttraining;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("calculator")
public class CalculatorResource {

    @Path("add")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public int addNumbers() {
        int num1 = 10;
        int num2 = 20;
        return num1 + num2;
    }

    @Path("multiply")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public int multiplyNumbers() {
        int num1 =2;
        int num2 = 60;
        return num1 * num2;
    }
}
