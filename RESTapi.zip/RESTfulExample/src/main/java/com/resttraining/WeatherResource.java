package com.resttraining;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("weather")
public class WeatherResource {

    @Path("today")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getWeatherToday() {
        return "The weather today is sad!";
    }

    @Path("forecast")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getWeatherForecast() {
        return "The weather forecast predicts rain ice cream tomorrow.";
    }
}
